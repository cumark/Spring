package spring5;

public class User {
    public void add(){

            System.out.println("add......");

    }
}
